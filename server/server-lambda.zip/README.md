# Lambda Setup

```bash
# Install the serverless npm package
npm install -g serverless

# Create AWS Resources in the serverless.yml file
sls deploy -v
```